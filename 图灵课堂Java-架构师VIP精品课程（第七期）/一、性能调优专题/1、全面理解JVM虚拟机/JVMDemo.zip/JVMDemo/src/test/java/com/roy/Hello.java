package com.roy;

import java.util.Scanner;

public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello World");
        Scanner scanner = new Scanner(System.in);
        scanner.next();
    }
}
