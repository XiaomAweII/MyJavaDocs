package com.roy.classLoader;

public class SecretUtil {

    public String hello(){
        return "Hello";
    }
}
