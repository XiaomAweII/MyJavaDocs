package java;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        Scanner scanner = new Scanner(System.in);
        scanner.next();
    }
}
