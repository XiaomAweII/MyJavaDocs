package com.xushu.circulardependencies.One;

/**
 * Created by xsls
 */
public interface IAService {

	void say();
}
