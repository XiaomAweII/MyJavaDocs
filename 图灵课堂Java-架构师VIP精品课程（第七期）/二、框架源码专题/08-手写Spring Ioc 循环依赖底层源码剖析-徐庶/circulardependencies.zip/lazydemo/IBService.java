package com.xushu.circulardependencies.lazydemo;

/**
 * Created by xsls
 */
public interface IBService {

	void say();
}
