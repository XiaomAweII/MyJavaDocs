package com.xushu.circulardependencies.closedemo;

/**
 * Created by xsls on 2019/10/14.
 */
public interface IInstanceA {

	void say();
}
