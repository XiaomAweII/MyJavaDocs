package com.xushu.circulardependencies.aopdemo;

/**
 * Created by xsls on 2019/10/14.
 */
public interface IInstanceB {

	void say();
}
