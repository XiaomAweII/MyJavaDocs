package org.tuling.vip_es_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VipEsDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(VipEsDemoApplication.class, args);
    }

}
