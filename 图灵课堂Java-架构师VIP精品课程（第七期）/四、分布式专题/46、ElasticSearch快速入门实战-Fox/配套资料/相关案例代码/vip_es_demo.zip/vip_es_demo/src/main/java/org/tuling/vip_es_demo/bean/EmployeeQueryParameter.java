package org.tuling.vip_es_demo.bean;

/**
 * @author: Fox
 * @Desc:
 **/
public record EmployeeQueryParameter(
    String keyword            //搜索的关键词
){}