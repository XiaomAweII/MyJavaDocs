package com.roy.rabbitmq.basic;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @auth roykingw
 */
public class FirstConsumer {
    private static final String HOST_NAME="192.168.65.193";
    private static final int HOST_PORT=5672;
    private static final String QUEUE_NAME="test3";
    public static final String USER_NAME="admin";
    public static final String PASSWORD="admin";
    public static final String VIRTUAL_HOST="/mirror";

    public static void main(String[] args) throws Exception{
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost(HOST_NAME);
        factory.setPort(HOST_PORT);
        factory.setUsername(USER_NAME);
        factory.setPassword(PASSWORD);
        factory.setVirtualHost(VIRTUAL_HOST);
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        /**
         * 声明一个对列。几个参数依次为： 队列名，durable是否实例化；exclusive：是否独占；autoDelete：是否自动删除；arguments:参数
         * 这几个参数跟创建队列的页面是一致的。
         * 如果Broker上没有队列，那么就会自动创建队列。
         * 但是如果Broker上已经由了这个队列。那么队列的属性必须匹配，否则会报错。
         */
        Map<String,Object> params = new HashMap<>();
//        params.put("x-queue-type","quorum");
//        params.put("x-expires",10000);
//        channel.queueDeclare("quorumQueue", true, false, false, params);

//        params.put("x-queue-type","stream");
//        params.put("x-max-length-bytes", 20_000_000_000L); // maximum stream size: 20 GB
//        params.put("x-stream-max-segment-size-bytes", 100_000_000); // size of segment files: 100 MB
//        channel.queueDeclare("streamQueue", true, false, false, params);
        //临时队列
//        String queueName = channel.queueDeclare().getQueue()
        channel.queueDeclare(QUEUE_NAME, true, false, false, params);
        //每个worker同时最多只处理一个消息
//        channel.basicQos(3);
        //回调函数，处理接收到的消息
        Consumer myconsumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                                       AMQP.BasicProperties properties, byte[] body)
                    throws IOException {
                System.out.println("========================");
                String routingKey = envelope.getRoutingKey();
                System.out.println("routingKey >"+routingKey);
                String contentType = properties.getContentType();
                System.out.println("contentType >"+contentType);
                long deliveryTag = envelope.getDeliveryTag();
                System.out.println("deliveryTag >"+deliveryTag);
                System.out.println("content:"+new String(body,"UTF-8"));
                // (process the message components here ...)
                channel.basicAck(deliveryTag, true);
            }
        };
        //从test1队列接收消息
        channel.basicConsume(QUEUE_NAME, false,myconsumer);
        //主动拿一批消息 如果没有消息,getResponse就是null。
//        GetResponse getResponse = channel.basicGet(QUEUE_NAME, false);
//        byte[] body = getResponse.getBody();
//        Envelope envelope = getResponse.getEnvelope();
//        int messageCount = getResponse.getMessageCount();
//        AMQP.BasicProperties props = getResponse.getProps();
//
//        System.out.println("========================");
//        String routingKey = envelope.getRoutingKey();
//        System.out.println("routingKey >"+routingKey);
//        String contentType = props.getContentType();
//        System.out.println("contentType >"+contentType);
//        long deliveryTag = envelope.getDeliveryTag();
//        System.out.println("deliveryTag >"+deliveryTag);
//        System.out.println("messageCount >"+messageCount);
//        System.out.println("content:"+new String(body,"UTF-8"));
////         (process the message components here ...)
//        channel.basicAck(deliveryTag, false);
////        拿完消息业务就结束了。需要关闭连接，释放资源。
//        channel.close();
//        connection.close();

    }
}
