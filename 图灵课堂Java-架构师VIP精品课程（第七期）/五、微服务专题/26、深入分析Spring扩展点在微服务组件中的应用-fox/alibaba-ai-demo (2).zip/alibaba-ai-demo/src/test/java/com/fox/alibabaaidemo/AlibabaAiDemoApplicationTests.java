package com.fox.alibabaaidemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlibabaAiDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
