package com.fox.alibabaaidemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlibabaAiDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AlibabaAiDemoApplication.class, args);
    }

}
