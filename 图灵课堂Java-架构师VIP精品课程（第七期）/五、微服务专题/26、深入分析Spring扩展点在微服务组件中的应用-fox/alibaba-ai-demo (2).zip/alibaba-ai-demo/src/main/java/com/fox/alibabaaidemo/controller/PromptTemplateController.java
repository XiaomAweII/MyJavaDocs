package com.fox.alibabaaidemo.controller;

import com.alibaba.cloud.ai.prompt.ConfigurablePromptTemplate;
import com.alibaba.cloud.ai.prompt.ConfigurablePromptTemplateFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/ai")
public class PromptTemplateController {

  private final ChatClient chatClient;

  private final ConfigurablePromptTemplateFactory configurablePromptTemplateFactory;

  @Autowired
  public PromptTemplateController(ChatClient.Builder builder,
                                  ConfigurablePromptTemplateFactory configurablePromptTemplateFactory) {
    this.chatClient = builder.build();
    this.configurablePromptTemplateFactory = configurablePromptTemplateFactory;
  }

  @GetMapping("/prompt-template")
  public AssistantMessage generate(@RequestParam(value = "author") String author) {
    ConfigurablePromptTemplate template = configurablePromptTemplateFactory.create("test-template",
            "请列出{author}所写的三本最著名的书");
    Prompt prompt;

    if (StringUtils.hasText(author)) {
      prompt = template.create(Map.of("author", author));
    } else {
      prompt = template.create();
    }
    System.out.println(prompt);
    return chatClient.prompt(prompt).call().chatResponse().getResult().getOutput();
  }

}