package com.tuling.learnjuc.sync;

import lombok.Data;

/**
 * @author: Fox
 * @Desc:
 **/
@Data
public class User {

    private String username;
    private int age;
}
