package com.tuling.learnjuc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnJucApplicationTests {

    @Test
    void contextLoads() {
    }

}
