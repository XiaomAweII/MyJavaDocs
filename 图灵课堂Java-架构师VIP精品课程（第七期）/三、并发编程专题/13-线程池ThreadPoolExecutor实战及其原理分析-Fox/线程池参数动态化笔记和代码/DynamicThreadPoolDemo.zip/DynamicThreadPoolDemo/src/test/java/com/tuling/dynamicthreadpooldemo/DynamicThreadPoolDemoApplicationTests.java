package com.tuling.dynamicthreadpooldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicThreadPoolDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
