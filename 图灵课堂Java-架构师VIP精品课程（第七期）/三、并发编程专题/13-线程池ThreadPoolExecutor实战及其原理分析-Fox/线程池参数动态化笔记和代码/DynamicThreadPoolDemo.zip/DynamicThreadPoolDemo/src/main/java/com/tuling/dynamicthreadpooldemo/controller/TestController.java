package com.tuling.dynamicthreadpooldemo.controller;

import com.tuling.dynamicthreadpooldemo.threadpool.MyDynamicThreadPool;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.ThreadPoolExecutor;

@RestController
@Slf4j
public class TestController {

    @Resource
    private MyDynamicThreadPool dynamicThreadPool;

    @RequestMapping("/execute")
    public void execute(int num){

        for(int i=0;i<num;i++){
            dynamicThreadPool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        log.info(Thread.currentThread().getName()+"开始执行任务");
                        Thread.sleep(10000);
                        //log.info(Thread.currentThread().getName()+"执行任务完成");
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
        }
        dynamicThreadPool.print();
    }


    @Resource
    private ThreadPoolExecutor dtpExecutor;

    @RequestMapping("/dtp")
    public void dtp(int num){
        for(int i=0;i<num;i++) {
            dtpExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        System.out.println(Thread.currentThread().getName()+"开始执行任务");
                        Thread.sleep(10000);
                        //System.out.println(Thread.currentThread().getName()+"执行任务完成");
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
        }
        System.out.println("核心线程数：" + dtpExecutor.getCorePoolSize() + " " +"最大线程数：" + dtpExecutor.getMaximumPoolSize()
                +" " + "阻塞队列数：" + dtpExecutor.getQueue().size()  +" " + "活跃线程数：" + dtpExecutor.getActiveCount());
    }

}