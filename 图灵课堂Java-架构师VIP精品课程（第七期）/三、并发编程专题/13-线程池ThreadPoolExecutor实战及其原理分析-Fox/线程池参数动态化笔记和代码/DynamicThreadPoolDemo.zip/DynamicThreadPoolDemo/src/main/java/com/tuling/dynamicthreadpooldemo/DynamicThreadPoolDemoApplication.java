package com.tuling.dynamicthreadpooldemo;

import org.dromara.dynamictp.core.spring.EnableDynamicTp;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableDynamicTp
@SpringBootApplication
public class DynamicThreadPoolDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DynamicThreadPoolDemoApplication.class, args);
    }

}
